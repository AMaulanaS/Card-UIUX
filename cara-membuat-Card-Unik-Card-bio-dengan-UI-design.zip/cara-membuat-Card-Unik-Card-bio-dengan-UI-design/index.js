alert("Kartu Bio Johan");

window.onload=function(){
    document.getElementById("loader").style.display ="none";
    document.getElementById("card").style.display="block";
}